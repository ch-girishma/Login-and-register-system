const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(express.json());
app.use(cors());

mongoose.connect('mongodb://localhost:27017/login_registration', { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
    console.log('Connected to MongoDB');
});

const userSchema = new mongoose.Schema({
    email: String,
    password: String,
});

const User = mongoose.model('User', userSchema);

app.post('/register', (req, res) => {
    const { register_username, register_email, register_password } = req.body;

    User.findOne({ email: register_email })
        .then(existingUser => {
            if (existingUser) {
                console.log('Registration failed: Email already registered');
                res.status(409).send('Email already registered');
            } else {
                const newUser = new User({
                    email: register_email,
                    password: register_password,
                });

                newUser.save()
                    .then(() => {
                        console.log('User registered successfully:', newUser);
                        res.status(201).send('Registration successful!');
                    })
                    .catch(saveErr => {
                        console.error('Error during registration:', saveErr);
                        res.status(500).send('Internal Server Error');
                    });
            }
        })
        .catch(err => {
            console.error('Error during registration:', err);
            res.status(500).send('Internal Server Error');
        });
});

app.post('/login', (req, res) => {
    const { login_email, login_password } = req.body;

    User.findOne({ email: login_email, password: login_password })
        .then(user => {
            if (user) {
                console.log('Login successful for user:', user.email);
                res.status(200).send('Login successful!');
            } else {
                console.log('Login failed: Invalid login details');
                res.status(401).send('Invalid login details');
            }
        })
        .catch(err => {
            console.error('Error during login:', err);
            res.status(500).send('Internal Server Error');
        });
});

app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
});
